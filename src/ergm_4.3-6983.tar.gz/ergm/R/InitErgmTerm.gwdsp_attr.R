################################################################################
InitErgmTerm.gwdsp_attr<-function (nw, arglist, cache.sp=FALSE, gw.cutoff=30, ...) {
  a <- check.ErgmTerm(nw, arglist,
                      varnames = c("decay","attr","fixed","cutoff", "diff", "levels"),
                      vartypes = c("numeric",ERGM_VATTR_SPEC,"logical","numeric", "logical",ERGM_LEVELS_SPEC),
                      defaultvalues = list(NULL, NULL, TRUE, gw.cutoff, FALSE, NULL),
                      required = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))
  attrarg <- a$attr
  levels <- a$levels      
  decay<-a$decay;fixed<-a$fixed
  cutoff<-a$cutoff
  decay=decay[1] # Not sure why anyone would enter a vector here, but...
  if(!fixed){ 
   ergm_Init_abort("Only", sQuote("fixed=TRUE")," has been coded for gwdsp terms with attributes.")
  }

  diff <- a$diff
  if(!is.null(attrarg)) {
    nodecov <- ergm_get_vattr(attrarg, nw)
    attrname <- attr(nodecov, "name")
    u <- ergm_attr_levels(levels, nodecov, nw, levels = sort(unique(nodecov)))
    nodecov <- match(nodecov,u,nomatch=length(u)+1)
    ui <- seq(along=u)
    if (!diff) {
      coef.names <- paste("gwdsp.fixed",decay,attrname,sep=".")
      inputs <- c(decay, nodecov)
      if(is.directed(nw)){dname <- "gwtdsp"}else{dname <- "gwdsp_attr"}
      list(name=dname, coef.names=coef.names, inputs=inputs, auxiliaries=if(cache.sp) .spcache.aux(if(is.directed(nw)) "OTP" else "UTP") else NULL)
    } else {
      ergm_Init_abort("Only", sQuote("diff=FALSE")," has been coded for gwdsp terms with attributes.")
      if(is.directed(nw)){dname <- "gwtdsp"}else{dname <- "gwdsp_attr"}
      coef.names <- paste("gwdsp",attrname, u, sep=".")
      inputs <- c(ui, nodecov)
      attr(inputs, "ParamsBeforeCov") <- length(ui)
      list(name=dname, coef.names=coef.names, inputs=inputs, minval=0)
    }
  }else{
#   ergm_Init_abort("Term ", sQuote("gwdsp_attr")," requires an attribute.")
    coef.names <- "gwdsp"
    inputs <- NULL
    if(is.null(a$decay)) stop("Term 'gwdsp' with 'fixed=TRUE' requires a decay parameter 'decay'.", call.=FALSE)

    coef.names <- paste("gwdsp.fixed.",decay,sep="")
    if(is.directed(nw)){dname <- "gwtdsp"}else{dname <- "gwdsp"}
    list(name=dname, coef.names=coef.names, inputs=c(decay), auxiliaries=if(cache.sp) .spcache.aux(if(is.directed(nw)) "OTP" else "UTP") else NULL)
  }
}
