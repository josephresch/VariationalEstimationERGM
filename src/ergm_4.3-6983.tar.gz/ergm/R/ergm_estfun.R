#  File R/ergm_estfun.R in package ergm, part of the
#  Statnet suite of packages for network analysis, https://statnet.org .
#
#  This software is distributed under the GPL-3 license.  It is free,
#  open source, and has the attribution requirements (GPL Section 7) at
#  https://statnet.org/attribution .
#
#  Copyright 2003-2022 Statnet Commons
################################################################################
#' Compute the Sample Estimating Function Values of an ERGM.
#'
#' The estimating function for an ERGM is the score function: the
#' gradient of the log-likelihood, equalling \eqn{\eta'(\theta)^\top
#' \{g(y)-\mu(\theta)\}}, where \eqn{g(y)} is a \eqn{p}-vector of
#' observed network sufficient statistic, \eqn{\mu(\theta)} is the
#' expected value of the sufficient statistic under the model for
#' parameter value \eqn{\theta}, and \eqn{\eta'(\theta)} is the
#' \eqn{p} by \eqn{q} Jacobian matrix of the mapping from curved
#' parameters to natural parmeters.  If the model is linear, all
#' non-offset statistics are passed. If the model is curved, the score
#' estimating equations (3.1) by Hunter and Handcock (2006) are given
#' instead.
#'
#' @param stats An object representing sample statistics with observed values subtracted out.
#' @param theta Model parameter \eqn{q}-vector.
#' @param model An [`ergm_model`] object or its `etamap` element.
#' @param ... Additional arguments for methods.
#'
#' @return An object of the same class as `stats` containing
#'   \eqn{q}-vectors of estimating function values.
#' @keywords internal
#' @export
ergm.estfun <- function(stats, theta, model, exclude=NULL, ...){
  UseMethod("ergm.estfun")
}

#' @describeIn ergm.estfun Method for numeric vectors of length \eqn{p}.
#' @export
ergm.estfun.numeric <- function(stats, theta, model, exclude=NULL, ...){
  etamap <- if(is(model, "ergm_model")) model$etamap else model
  estf <- c(ergm.etagradmult(theta,stats,etamap))[!etamap$offsettheta]
  names(estf) <- (if(is(model, "ergm_model")) param_names(model, FALSE) else names(theta))[!etamap$offsettheta]
  if(is(model, "ergm_model")){
   names(estf) <- param_names(model, FALSE)[!etamap$offsettheta]
  }else{
    if(!is.null(names(theta))){
      names(estf) <- names(theta)[!etamap$offsettheta]
    }else{
      a <- names(stats)[!etamap$offsettheta]
      if(length(a)==length(estf)) names(estf) <- a
    }
  }
  # Exclude statistics that are not expected to have a specific mean
  if(!is.null(exclude)){
    x.exclude <- match(exclude,names(estf))
    if(!is.na(x.exclude)){
     estf <- estf[-x.exclude]
    }
  }
  -estf
}

#' @describeIn ergm.estfun Method for matrices with \eqn{p} columns.
#' @export
ergm.estfun.matrix <- function(stats, theta, model, exclude=NULL, ...){
  etamap <- if(is(model, "ergm_model")) model$etamap else model
  estf <- t(ergm.etagradmult(theta,t(as.matrix(stats)),etamap))[,!etamap$offsettheta,drop=FALSE]
  if(is(model, "ergm_model")){
   colnames(estf) <- param_names(model, FALSE)[!etamap$offsettheta]
  }else{
    if(!is.null(names(theta))){
      colnames(estf) <- names(theta)[!etamap$offsettheta]
    }else{
      a <- colnames(stats)[!etamap$offsettheta]
      if(length(a)==ncol(estf)) colnames(estf) <- a
    }
  }
# Exclude statistics that are not expected to have a specific mean
  if(!is.null(exclude)){
    x.exclude <- match(exclude,colnames(as.matrix(estf)))
    if(!is.na(x.exclude)){
     estf <- estf[,-x.exclude,drop=FALSE]
    }
  }
  -estf
}

#' @describeIn ergm.estfun Method for [`mcmc`] objects with \eqn{p} variables.
#' @export
ergm.estfun.mcmc <- function(stats, theta, model, exclude=NULL, ...){
  mcmc(ergm.estfun(as.matrix(stats), theta, model, exclude=exclude), start=start(stats), end=end(stats), thin=thin(stats))
}

#' @describeIn ergm.estfun Method for  [`mcmc.list`] objects with \eqn{p} variables.
#' @export
ergm.estfun.mcmc.list <- function(stats, theta, model, exclude=NULL, ...){
  lapply.mcmc.list(stats, ergm.estfun, theta, model, exclude=exclude)
}
