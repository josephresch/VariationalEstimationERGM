/*  File src/changestats_concurrentties.c in package ergm, part of the Statnet suite
 *  of packages for network analysis, https://statnet.org .
 *
 *  This software is distributed under the GPL-3 license.  It is free,
 *  open source, and has the attribution requirements (GPL Section 7) at
 *  https://statnet.org/attribution
 *
 *  Copyright 2003-2020 Statnet Commons
 */
#include "changestats_gwdsp_attr.h"
#include "ergm_storage.h"
#include "ergm_dyad_hashmap.h"

/*****************
 changestat: d_gwdsp_attr
****************/
C_CHANGESTAT_FN(c_gwdsp_attr) {
  StoreDyadMapUInt *spcache = N_AUX ? AUX_STORAGE : NULL;
  Edge e, f;
  int echange, ochange;
  int L2tu, L2uh;
  Vertex u, v;
  double alpha, oneexpa, cumchange;
  double tailattr;
  
  /* *** don't forget tail -> head */    
  alpha = INPUT_PARAM[0];
  oneexpa = 1.0-exp(-alpha);
  
    cumchange=0.0;
    ochange = edgestate ? -1 : 0;
    echange = 2*ochange + 1;
    tailattr = INPUT_ATTRIB[tail];
    if(EQUAL(tailattr,INPUT_ATTRIB[head])){
    /* step through outedges of head */
    STEP_THROUGH_OUTEDGES(head, e, u){
      if(EQUAL(tailattr,INPUT_ATTRIB[u])){
      if (u != tail){
  	if(spcache) L2tu = GETDMUI(tail,u,spcache);
  	else{
	  L2tu=0;
	  /* step through outedges of u */
	  STEP_THROUGH_OUTEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
	    if(IS_UNDIRECTED_EDGE(v, tail)) L2tu++;
	   }
	  }
	  /* step through inedges of u */
	  STEP_THROUGH_INEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
	    if(IS_UNDIRECTED_EDGE(v, tail)) L2tu++;
	   }
	  }
  	}
	L2tu+=ochange;
        cumchange += pow(oneexpa,(double)L2tu);
      }
     }
    }
    /* step through inedges of head */
    STEP_THROUGH_INEDGES(head, e, u){
      if(EQUAL(tailattr,INPUT_ATTRIB[u])){
      if (u != tail){
  	if(spcache) L2tu = GETDMUI(tail,u,spcache);
  	else{
	  L2tu=0;
	  /* step through outedges of u */
	  STEP_THROUGH_OUTEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
	    if(IS_UNDIRECTED_EDGE(v, tail)) L2tu++;
	   }
	  }
	  /* step through inedges of u */
	  STEP_THROUGH_INEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
            if(IS_UNDIRECTED_EDGE(v, tail)) L2tu++;
	   }
	  }
  	}
	L2tu+=ochange;
        cumchange += pow(oneexpa,(double)L2tu);
      }
     }
    }
    
    /* step through outedges of tail  */
    STEP_THROUGH_OUTEDGES(tail, e, u){
      if(EQUAL(tailattr,INPUT_ATTRIB[u])){
      if (u != head){
  	if(spcache) L2uh = GETDMUI(u,head,spcache);
  	else{
	  L2uh=0;
	  /* step through outedges of u */
	  STEP_THROUGH_OUTEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
	    if(IS_UNDIRECTED_EDGE(v, head)) L2uh++;
	   }
	  }
	  /* step through inedges of u */
	  STEP_THROUGH_INEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
	    if(IS_UNDIRECTED_EDGE(v, head)) L2uh++;
	   }
	  }
  	}
	L2uh+=ochange;
        cumchange += pow(oneexpa,(double)L2uh);
      }
     }
    }
    /* step through inedges of tail */
    STEP_THROUGH_INEDGES(tail, e, u){
      if(EQUAL(tailattr,INPUT_ATTRIB[u])){
      if (u != head){
  	if(spcache) L2uh = GETDMUI(u,head,spcache);
  	else{
	  L2uh=0;
	  /* step through outedges of u */
	  STEP_THROUGH_OUTEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
	    if(IS_UNDIRECTED_EDGE(v, head)) L2uh++;
	   }
	  }
	  /* step through inedges of u */
	  STEP_THROUGH_INEDGES(u, f, v){
           if(EQUAL(tailattr,INPUT_ATTRIB[v])){
	    if(IS_UNDIRECTED_EDGE(v, head)) L2uh++;
	   }
	  }
	}
	L2uh+=ochange;
        cumchange += pow(oneexpa,(double)L2uh);
        }
     }
    }
    
    }
    cumchange  = echange*cumchange;
    (CHANGE_STAT[0]) += cumchange;
}
