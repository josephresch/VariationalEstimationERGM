/*  File src/changestats_gwesp_attr_OTP.c in package ergm, part of the Statnet suite
 *  of packages for network analysis, https://statnet.org .
 *
 *  This software is distributed under the GPL-3 license.  It is free,
 *  open source, and has the attribution requirements (GPL Section 7) at
 *  https://statnet.org/attribution
 *
 *  Copyright 2003-2020 Statnet Commons
 */
#include "changestats_gwesp_attr_OTP.h"
#include "changestats_dgw_sp.h"
#include "ergm_dyad_hashmap.h"

/*****************
 changestat: d_gwesp_attr_OTP
 This is the OTP version - Outgoing two-path (i->k->j)
*****************/
C_CHANGESTAT_FN(c_gwesp_attr_OTP) { 
  StoreDyadMapUInt *spcache = N_AUX ? AUX_STORAGE : NULL;
  int echange, ochange;
  int L2th, L2tk, L2kh;
  double alpha, oneexpa, cumchange;
  double tailattr;
  
  alpha = INPUT_PARAM[0];
  oneexpa = 1.0-exp(-alpha);
  
    cumchange=0.0;
    if(spcache) L2th = GETDMUI(tail,head,spcache); // spcache has OTP two-paths
    else L2th=0;
    echange = (IS_OUTEDGE(tail, head) == 0) ? 1 : -1;
    ochange = (echange - 1)/2;
    tailattr = INPUT_ATTRIB[tail];
    if(EQUAL(tailattr,INPUT_ATTRIB[head])){
    //Rprintf("\tEdge change is %d\n",echange);
    /* step through outedges of head (i.e., k: h->k)*/
    //Rprintf("Walking through outedges of head\n",echange);
    EXEC_THROUGH_OUTEDGES(tail,e,k, {
      if(EQUAL(tailattr,INPUT_ATTRIB[k])){
      if(!spcache&&(k!=head)&&(IS_OUTEDGE(k,head))){
              /*We have a t->k->h two-path, so add it to our count.*/
              L2th++;
      }
      if((k!=head)&&(IS_OUTEDGE(head,k))){ /*Only use contingent cases*/
        //Rprintf("\tk==%d, passed criteria\n",k);
        if(spcache) L2tk = GETDMUI(tail,k,spcache);
	else{
	  /*We have a h->k->t two-path, so add it to our count.*/
	  L2tk=0;
	  /*Now, count # u such that t->u->k (to find t->k's ESP value)*/
	  EXEC_THROUGH_INEDGES(k,f,u, {
	   if(EQUAL(tailattr,INPUT_ATTRIB[u])){
	      //Rprintf("\t\tTrying u==%d\n",u);
	      if(u!=tail) 
		L2tk+=IS_OUTEDGE(tail,u); /*Increment if there is a trans edge*/
		}});
	}
        /*Update the changestat for the t->k edge*/
        //Rprintf("\t2-path count was %d\n",L2hk);
	L2tk+=ochange;
	cumchange += pow(oneexpa,(double)L2tk);
      }
    }});

    /* step through inedges of head (i.e., k: k->h)*/
    //Rprintf("Walking through inedges of head\n",k);
    EXEC_THROUGH_INEDGES(head,e,k, {
      if(EQUAL(tailattr,INPUT_ATTRIB[k])){
      if((k!=tail)&&(IS_OUTEDGE(k,tail))){ /*Only use contingent cases*/
        //Rprintf("\tk==%d, passed criteria\n",k);
        if(spcache) L2kh = GETDMUI(k,head,spcache);
	else{
	  L2kh=0;
	  /*Now, count # u such that k->u->j (so that we know k's ESP value)*/
	  EXEC_THROUGH_OUTEDGES(k,f,u, {
	   if(EQUAL(tailattr,INPUT_ATTRIB[u])){
	      if(u!=head) 
		L2kh+=IS_OUTEDGE(u,head); /*Increment if there is a trans edge*/
		}});
	}
        /*Finally, update the changestat for the t->h edge*/
        //Rprintf("2-path count for (t,h) was %d\n",L2th);
        L2kh+=ochange;
        cumchange += pow(oneexpa,(double)L2kh);
      }
      }});

    if(alpha < 100.0){
      cumchange += exp(alpha)*(1.0-pow(oneexpa,(double)L2th)) ;
    }else{
      cumchange += (double)L2th;
    }
    cumchange  = echange*cumchange;
    (CHANGE_STAT[0]) += cumchange;
    }
}

