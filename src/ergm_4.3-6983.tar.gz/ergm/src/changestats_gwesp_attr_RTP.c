/*  File src/changestats_gwesp_attr_RTP.c in package ergm, part of the Statnet suite
 *  of packages for network analysis, https://statnet.org .
 *
 *  This software is distributed under the GPL-3 license.  It is free,
 *  open source, and has the attribution requirements (GPL Section 7) at
 *  https://statnet.org/attribution
 *
 *  Copyright 2003-2020 Statnet Commons
 */
#include "changestats_gwesp_attr_RTP.h"
#include "changestats_dgw_sp.h"
#include "ergm_dyad_hashmap.h"

/*****************
 changestat: d_gwesp_attr_RTP
 This is the RTP version - Reciprocated two-path (i<->k<->j)
*****************/
C_CHANGESTAT_FN(c_gwesp_attr_RTP) { 
  StoreDyadMapUInt *spcache = N_AUX ? AUX_STORAGE : NULL;
  int echange, ochange, htedge;
  int L2th,L2tk,L2kt; /*Two-path counts for various edges*/
  double alpha, oneexpa, cumchange;
  double tailattr;
  
  alpha = INPUT_PARAM[0];
  oneexpa = 1.0-exp(-alpha);
  
    cumchange=0.0;
    if(spcache) L2th = GETDMUI(tail,head,spcache); // spcache has OTP two-paths
    else L2th=0;
    echange = (IS_OUTEDGE(tail, head) == 0) ? 1 : -1;
    ochange = (echange - 1)/2;
    htedge=IS_OUTEDGE(head,tail);  /*Is there an h->t (reciprocating) edge?*/
    tailattr = INPUT_ATTRIB[tail];
    if(EQUAL(tailattr,INPUT_ATTRIB[head])){
    //Rprintf("\tEdge change is %d\n",echange);
    /* step through outedges of head (i.e., k: h->k)*/
    //Rprintf("Walking through outedges of head\n",echange);
    EXEC_THROUGH_INEDGES(tail,e,k, {
      if(EQUAL(tailattr,INPUT_ATTRIB[k])){
      if(k!=head){
        if(!spcache)
          /*Do we have a t<->k<->h TP?  If so, add it to our count.*/
          L2th+=(IS_OUTEDGE(tail,k)&&IS_OUTEDGE(head,k)&&IS_OUTEDGE(k,head));

          if(htedge&&IS_OUTEDGE(head,k)&&IS_OUTEDGE(k,head)){ /*Only consider stats that could change*/
          if(spcache) L2kt = GETDMUI(k,tail,spcache);
          else{
          L2kt=0;
          /*Now, count # u such that k<->u<->t (to get (k,t)'s ESP value)*/
          EXEC_THROUGH_OUTEDGES(k,f,u, {
	   if(EQUAL(tailattr,INPUT_ATTRIB[u])){
            if((u!=tail)&&(IS_OUTEDGE(u,k)))
              L2kt+=(IS_OUTEDGE(u,tail)&&IS_OUTEDGE(tail,u));  /*k<->u<->t?*/
          }});
          }
        /*Update the changestat for the k->t edge*/
	L2kt+=ochange;
	cumchange += pow(oneexpa,(double)L2kt);
      }
     }
    }});

    /* step through outedges of tail (t->k: k!=h,h->t,k<->h)*/
    EXEC_THROUGH_OUTEDGES(tail,e,k, {
      if(EQUAL(tailattr,INPUT_ATTRIB[k])){
      if(k!=head){
        if(htedge&&IS_OUTEDGE(head,k)&&IS_OUTEDGE(k,head)){ /*Only consider stats that could change*/
          if(spcache) L2tk = GETDMUI(tail,k,spcache);
          else{
          L2tk=0;
          /*Now, count # u such that k<->u<->t (to get (tk)'s ESP value)*/
          EXEC_THROUGH_OUTEDGES(k,f,u, {
	   if(EQUAL(tailattr,INPUT_ATTRIB[u])){
            if((u!=tail)&&(IS_OUTEDGE(u,k)))
              L2tk+=(IS_OUTEDGE(u,tail)&&IS_OUTEDGE(tail,u));  /*k<->u<->t?*/
          }});
          }

        /*Update the changestat for the k->t edge*/
        //Rprintf("\t2-path count was %d\n",L2kh);
        L2tk+=ochange;
        cumchange += pow(oneexpa,(double)L2tk);
       }
      }
      }});

    if(alpha < 100.0){
      cumchange += exp(alpha)*(1.0-pow(oneexpa,(double)L2th)) ;
    }else{
      cumchange += (double)L2th;
    }
    cumchange  = echange*cumchange;
    (CHANGE_STAT[0]) += cumchange;
    }
}

